const { env } = process;

exports.googleApiKey = env.googleApiKey;
exports.googleTtsApiUrl = env.googleTtsApiUrl;
